//
//  RNCmbSdkHelper.m
//  RNCmbSdk
//
//  Created by Zhivko Manchev on 4/25/19.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "RCTCmbSdkHelper.h"

@implementation RCTCmbSdkHelper

- (void) startObserving{
    [NSNotificationCenter.defaultCenter removeObserver:self];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(appDidRotate:)
                                                 name:@"UIDeviceOrientationDidChangeNotification" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(cameraTriggerDidChange:)
                                                 name:@"MX_MOBILE_TRIGGER_NOTIFICATION" object:nil];
}

- (void) stopObserving{
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

// Observers
-(void) appDidRotate:(NSNotification *)notification {
    [self.delegate rotationObserverTriggered:notification];
}

-(void) cameraTriggerDidChange:(NSNotification *)notification {
    [self.delegate triggerObserverTriggered:notification];
}


@end
