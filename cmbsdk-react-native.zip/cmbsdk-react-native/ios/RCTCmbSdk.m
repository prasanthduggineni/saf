
#import "RCTCmbSdk.h"

// SVG
#import "CDMSVGParser.h"
#import "CDMSVGRenderer.h"

@implementation RCTCmbSdk

- (dispatch_queue_t)methodQueue
{
    return dispatch_get_main_queue();
}
RCT_EXPORT_MODULE()

CDMCameraMode param_cameraMode = 0;
CDMPreviewOption param_previewOptions = 0;
int param_triggerType = 2;
int param_deviceType = 0;
RCTPromiseResolveBlock cmb_pendingConnectionResolver;
RCTPromiseRejectBlock cmb_pendingConnectionRejecter;
NSString *cmbsdk_regKey = nil;

BOOL cmb_isScannerScanning = NO;
UIInterfaceOrientation currentAppOrientation;

// Scanner container view
UIView *scannerView;
// Scanner container view percentages
float position_xp = 0;
float position_yp = 0;
float position_wp = 100;
float position_hp = 50;
// Scanner container view actual dimensions
float param_positionX = 0;
float param_positionY = 0;
float param_sizeWidth = 100;
float param_sizeHeight = 50;

BOOL cmb_isScannerFullScreen = NO;
BOOL cmb_isScannerBelowStatusBar = YES;
BOOL cmb_stopScanningOnRotate = YES;

CMBReaderDevice *cmb_readerDevice;
RCTCmbSdkHelper *cmb_rnHelper;

+(BOOL)requiresMainQueueSetup {
    return YES;
}

- (instancetype)init
{
    self = [super init];
    if (self && cmb_readerDevice) {
        cmb_readerDevice.delegate = self;
        [cmb_readerDevice disconnect];
        if (cmb_rnHelper) {
            [cmb_rnHelper stopObserving];
        }
    }
    return self;
}

RCT_REMAP_METHOD(loadScanner, deviceType:(int)deviceType loadScannerResolver:(RCTPromiseResolveBlock)loadScannerResolver loadScannerRejecter:(RCTPromiseRejectBlock)loadScannerRejecter)
{
    [self loadScanner:deviceType loadScannerResolver:loadScannerResolver loadScannerRejecter:loadScannerRejecter];
}

-(void) loadScanner:(int) deviceType loadScannerResolver:(RCTPromiseResolveBlock)loadScannerResolver loadScannerRejecter:(RCTPromiseRejectBlock)loadScannerRejecter
{
    param_deviceType = deviceType;
    
    if (cmb_readerDevice && cmb_readerDevice.connectionState == CMBConnectionStateConnected) {
        cmb_readerDevice.delegate = self;
        [cmb_readerDevice disconnect];
        cmb_pendingConnectionResolver = loadScannerResolver;
        cmb_pendingConnectionRejecter = loadScannerRejecter;
        return;
    }
    
    if (param_deviceType == 1){
        currentAppOrientation = [[UIApplication sharedApplication]statusBarOrientation];
        if (!cmb_isScannerFullScreen) {
            [self performSelectorOnMainThread:@selector(setPreviewContainerPositionAndSize:) withObject:nil waitUntilDone:YES];
        }
        [self performSelectorOnMainThread:@selector(addScannerView) withObject:nil waitUntilDone:YES];
    }else
        [self performSelectorOnMainThread:@selector(removeScannerView) withObject:nil waitUntilDone:NO];
    
    switch (param_deviceType) {
        default:
        case 0:
            cmb_readerDevice = [CMBReaderDevice readerOfMXDevice];
            break;
            
            case 1:{
                cmb_readerDevice = [CMBReaderDevice readerOfDeviceCameraWithCameraMode:param_cameraMode previewOptions:param_previewOptions previewView:cmb_isScannerFullScreen ? nil : scannerView registrationKey:cmbsdk_regKey];
                
                [self performSelectorOnMainThread:@selector(setScannerViewHidden:) withObject:[NSNumber numberWithBool:YES] waitUntilDone:NO];
            }
            break;
    }
    
    cmb_readerDevice.delegate = self;
    if (loadScannerResolver) {
        loadScannerResolver(@(YES));
    }
    cmb_pendingConnectionRejecter = nil;
    cmb_pendingConnectionResolver = nil;
}

RCT_EXPORT_METHOD(registerSDK:(NSString*)arg){
    cmbsdk_regKey = arg;
}

RCT_REMAP_METHOD(getAvailability, availabilityResolver:(RCTPromiseResolveBlock)availabilityResolver availabilityRejecter:(RCTPromiseRejectBlock)availabilityRejecter)
{
    if ([self isReaderInit:availabilityRejecter]) {
        availabilityResolver(@(cmb_readerDevice.availability));
    }
}

RCT_EXPORT_METHOD(enableImage:(BOOL)arg enableImageResolver:(RCTPromiseResolveBlock)enableImageResolver enableImageRejecter:(RCTPromiseRejectBlock)enableImageRejecter){
    if ([self isReaderInit:enableImageRejecter]) {
        cmb_readerDevice.imageResultEnabled = arg;
        enableImageResolver(@(YES));
    }
}

RCT_EXPORT_METHOD(enableImageGraphics:(BOOL)arg enableGraphicsResolver:(RCTPromiseResolveBlock)enableGraphicsResolver enableGraphicsRejecter:(RCTPromiseRejectBlock)enableGraphicsRejecter){
    if ([self isReaderInit:enableGraphicsRejecter]) {
        [cmb_readerDevice setSVGResultEnabled:arg];
        enableGraphicsResolver(@(YES));
    }
}

RCT_EXPORT_METHOD(setParser:(int)arg setParserResolver:(RCTPromiseResolveBlock)setParserResolver setParserRejecter:(RCTPromiseRejectBlock)setParserRejecter){
    if ([self isReaderInit:setParserRejecter]) {
        if (arg >= 0 && arg <= CMBResultParserSCM) {
            [cmb_readerDevice setParser:arg];
            setParserResolver(@(YES));
        } else {
            setParserRejecter(@"0", @"setParser invalid argument", nil);
        }
    }
}

RCT_REMAP_METHOD(getConnectionState, getConnectionStateResolver:(RCTPromiseResolveBlock)getConnectionStateResolver getConnectionStateRejecter:(RCTPromiseRejectBlock)getConnectionStateRejecter){
    if ([self isReaderInit:getConnectionStateRejecter]) {
        getConnectionStateResolver(@(cmb_readerDevice.connectionState));
    }
}

RCT_REMAP_METHOD(connect, connectResolver:(RCTPromiseResolveBlock)connectResolver connectRejecter:(RCTPromiseRejectBlock)connectRejecter)
{
    if (!cmb_readerDevice.dataManSystem) {
        [self loadScanner:param_deviceType loadScannerResolver:nil loadScannerRejecter:nil];
    }
    cmb_readerDevice.delegate = self;
    if ([self isReaderInit:connectRejecter]) {
        [cmb_readerDevice connectWithCompletion:^(NSError *error) {
            if (error == nil) {
                connectResolver(@(YES));
            }else{
                connectRejecter(@"0", error.localizedDescription, error);
            }
        }];
    }
}

RCT_REMAP_METHOD(startScanning, startScanningResolver:(RCTPromiseResolveBlock)startScanningResolver startScanningRejecter:(RCTPromiseRejectBlock)startScanningRejecter)
{
    if (cmb_readerDevice != nil && cmb_readerDevice.connectionState == kCDMConnectionStateConnected) {
        [self performSelectorOnMainThread:@selector(setScannerViewHidden:) withObject:[NSNumber numberWithBool:NO] waitUntilDone:YES];
        [self toggleScannerWithBool:YES];
        startScanningResolver(@(YES));
    }else{
        startScanningRejecter(@"0",@"Reader device not initialized",nil);
    }
}

RCT_REMAP_METHOD(stopScanning, stoptScanningResolver:(RCTPromiseResolveBlock)stopScanningResolver stopScanningRejecter:(RCTPromiseRejectBlock)stopScanningRejecter)
{
    if ([self isReaderInit:stopScanningRejecter]) {
        [self stopScanning];
        stopScanningResolver(@(YES));
    }
}

-(void) stopScanning {
    [self performSelectorOnMainThread:@selector(setScannerViewHidden:) withObject:[NSNumber numberWithBool:YES] waitUntilDone:YES];
    [self toggleScannerWithBool:NO];
}

RCT_REMAP_METHOD(getDeviceBatteryLevel, batteryStateResolver:(RCTPromiseResolveBlock)batteryStateResolver batteryStateRejecter:(RCTPromiseRejectBlock)batteryStateRejecter)
{
    if ([self isReaderInit:batteryStateRejecter]) {
        [cmb_readerDevice getDeviceBatteryLevelWithCompletion:^(int batteryLevel, NSError *error) {
            if (error == nil) {
                batteryStateResolver(@(batteryLevel));
            }else{
                batteryStateRejecter(error.domain, error.localizedDescription, error);
            }
        }];
    }
}

RCT_EXPORT_METHOD(setSymbology:(int)symbology enabled:(BOOL)arg commandIdentifier:(nonnull NSString*) cmdIdentifier)
{
    if ([self isReaderInit:nil]) {
        [cmb_readerDevice setSymbology:symbology enabled:arg  completion:^(NSError *error) {
            NSLog(@"setSymbology:[%d] error:[%@]", symbology, error.description);
            if (self.bridge)
                [self sendEventWithName:@"cmbCommandCompletionEvent" body:@{@"commandID":cmdIdentifier, @"success": @(error == nil), @"message": (error != nil)?error.description:@"", @"eventType":@"setSymbology"}];
        }];
    }else{
        if (self.bridge)
            [self sendEventWithName:@"cmbCommandCompletionEvent" body:@{@"commandID":cmdIdentifier, @"success": @(NO), @"message": @"Reader device not initialized", @"eventType":@"setSymbology"}];
    }
}

RCT_EXPORT_METHOD(isSymbologyEnabled:(int)symbology commandIdentifier:(nonnull NSString*) cmdIdentifier)
{
    if ([self isReaderInit:nil]) {
        [cmb_readerDevice isSymbologyEnabled:symbology completion:^(BOOL enabled, NSError *error) {
            if (self.bridge)
                [self sendEventWithName:@"cmbCommandCompletionEvent" body:@{@"commandID":cmdIdentifier, @"success": @(error == nil), @"message": (error != nil)?error.description:@"", @"response":@(enabled), @"eventType":@"isSymbologyEnabled"}];
        }];
    }else{
        if (self.bridge)
            [self sendEventWithName:@"cmbCommandCompletionEvent" body:@{@"commandID":cmdIdentifier, @"success": @(NO), @"message": @"Reader device not initialized", @"eventType":@"isSymbologyEnabled"}];
    }
}

RCT_EXPORT_METHOD(setLightsOn:(BOOL)arg setLightsResolver:(RCTPromiseResolveBlock)setLightsResolver setLightsRejecter:(RCTPromiseRejectBlock)setLightsRejecter)
{
    if ([self isReaderInit:setLightsRejecter]) {
        [cmb_readerDevice setLightsON:arg completion:^(NSError *error) {
            if (error == nil) {
                setLightsResolver(@(YES));
            }else{
                setLightsRejecter(error.domain, error.localizedDescription, error);
            }
        }];
    }
}

RCT_REMAP_METHOD(isLightsOn, isLightsResolver:(RCTPromiseResolveBlock)isLightsResolver isLightsRejecter:(RCTPromiseRejectBlock)isLightsRejecter)
{
    if ([self isReaderInit:isLightsRejecter]) {
        [cmb_readerDevice getLightsStateWithCompletion:^(BOOL enabled, NSError *error) {
            if (error == nil) {
                isLightsResolver(@(enabled));
            }else{
                isLightsRejecter(error.domain, error.localizedDescription, error);
            }
        }];
    }
}

RCT_REMAP_METHOD(resetConfig, resetConfigResolver:(RCTPromiseResolveBlock)resetConfigResolver resetConfigRejecter:(RCTPromiseRejectBlock)resetConfigRejecter)
{
    if ([self isReaderInit:resetConfigRejecter]) {
        [cmb_readerDevice resetConfigWithCompletion:^(NSError *error) {
            if (error == nil) {
                resetConfigResolver(@(YES));
            }else{
                resetConfigRejecter(error.domain, error.localizedDescription, error);
            }
        }];
    }
}

RCT_EXPORT_METHOD(sendCommand:(NSString*)command commandIdentifier:(nonnull NSString*) cmdIdentifier)
{
    if ([self isReaderInit:nil]) {
        [cmb_readerDevice.dataManSystem sendCommand:command withCallback:^(CDMResponse *response) {
            if (self.bridge) {
                if (response.status == DMCC_STATUS_NO_ERROR) {
                    [self sendEventWithName:@"cmbCommandCompletionEvent" body:@{@"commandID":cmdIdentifier, @"success": @(YES), @"status": @(response.status), @"message": response.payload?response.payload:@"", @"eventType":@"command", @"command":command}];
                }else{
                    [self sendEventWithName:@"cmbCommandCompletionEvent" body:@{@"commandID":cmdIdentifier, @"success": @(NO), @"status": @(response.status), @"message": response.payload?response.payload:@"Command failed", @"eventType":@"command", @"command":command}];
                }
            }
        }];
    }else{
        if (self.bridge)
            [self sendEventWithName:@"cmbCommandCompletionEvent" body:@{@"commandID":cmdIdentifier, @"success": @(NO), @"message": @"Reader device not initialized", @"eventType":@"command", @"command":command}];
    }
}

-(BOOL) isReaderInit:(RCTPromiseRejectBlock)rejectBlock {
    if (cmb_readerDevice != nil) {
        return YES;
    }else{
        if (rejectBlock) {
            rejectBlock(@"0", @"Reader device not initialized", nil);
        }
        return NO;
    }
}

// CMBSDK DELEGATES
- (void)connectionStateDidChangeOfReader:(CMBReaderDevice *)reader{
    [self sendEventWithName:@"connectionStateDidChangeOfReaderEvent" body:@(reader?reader.connectionState:0)];
    if (reader.connectionState == kCDMConnectionStateDisconnected && cmb_pendingConnectionResolver) {
        [self loadScanner:param_deviceType loadScannerResolver:cmb_pendingConnectionResolver loadScannerRejecter:cmb_pendingConnectionRejecter];
    }
    
    if (reader.connectionState == kCDMConnectionStateConnected) {
        if (!cmb_rnHelper) {
            cmb_rnHelper = RCTCmbSdkHelper.new;
        }
        
        cmb_rnHelper.delegate = self;
        [cmb_rnHelper startObserving];
    } else if (reader.connectionState == kCDMConnectionStateConnected) {
        if (cmb_rnHelper) {
            [cmb_rnHelper stopObserving];
        }
    }
}

- (void)availabilityDidChangeOfReader:(CMBReaderDevice *)reader
{
    [self sendEventWithName:@"availabilityDidChangeOfReaderEvent" body:@(reader.availability)];
}

-(void)didReceiveReadResultFromReader:(CMBReaderDevice *)reader results:(CMBReadResults *)readResults
{
    NSMutableDictionary *json_resultDict = NSMutableDictionary.new;
    NSMutableArray *json_readResults = NSMutableArray.new;
    NSMutableArray *json_subReadResults = NSMutableArray.new;
    
    [json_resultDict setObject:readResults.XML forKey:@"xml"];
    
    if (readResults.readResults && readResults.readResults.count > 0) {
        [json_readResults addObject:[self dictionaryFromReadResult:readResults.readResults.firstObject]];
    }
    
    if (readResults.subReadResults && readResults.subReadResults.count > 0) {
        for (CMBReadResult* item in readResults.subReadResults) {
            [json_readResults addObject:[self dictionaryFromReadResult:item]];
            [json_subReadResults addObject:[self dictionaryFromReadResult:item]];
        }
    }
    
    [json_resultDict setObject:json_subReadResults forKey:@"subReadResults"];
    [json_resultDict setObject:json_readResults forKey:@"readResults"];
    
    [self sendEventWithName:@"didReceiveReadResultFromReaderEvent" body:json_resultDict];
}

- (NSMutableDictionary*) dictionaryFromReadResult:(CMBReadResult*) readResult {
    NSMutableDictionary *resultDict = [NSMutableDictionary new];
    
    [resultDict setObject:@(readResult.goodRead) forKey:@"goodRead"];
    
    if (readResult.goodRead) {
        [resultDict setObject:[NSNumber numberWithInt:(int)readResult.symbology] forKey:@"symbology"];
        [resultDict setObject:[self stringFromSymbology:readResult.symbology] forKey:@"symbologyString"];
        [resultDict setObject:readResult.readString forKey:@"readString"];
    } else {
        [resultDict setObject:@"NO READ" forKey:@"symbology"];
        [resultDict setObject:@"NO READ" forKey:@"symbologyString"];
        [resultDict setObject:@"" forKey:@"readString"];
    }    
    
    if (readResult.image) {
        NSData *imageData = UIImagePNGRepresentation(readResult.image);
        NSString *base64image = [imageData base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
        [resultDict setObject:base64image forKey:@"image"];
    }
    
    if (readResult.XML) {
        NSString* xmlStr = [[NSString alloc] initWithData:readResult.XML encoding:NSUTF8StringEncoding];
        [resultDict setObject:xmlStr forKey:@"xml"];
    }
    
    if (readResult.imageGraphics) {
        NSString* imageGraphicsStr = [[NSString alloc] initWithData:readResult.imageGraphics encoding:NSUTF8StringEncoding];
        [resultDict setObject:imageGraphicsStr forKey:@"imageGraphics"];
    }
    
    if (readResult.parsedText) {
        [resultDict setObject:readResult.parsedText forKey:@"parsedText"];
    }
    
    if (readResult.parsedJSON) {
        [resultDict setObject:readResult.parsedJSON forKey:@"parsedJSON"];
    }
    
    return resultDict;
}

RCT_EXPORT_METHOD(setPreviewContainerPositionAndSize:(NSArray*)args){
    if (args && args.count == 4) {
        position_xp = [args[0] floatValue];
        position_yp = [args[1] floatValue];
        position_wp = [args[2] floatValue];
        position_hp = [args[3] floatValue];
    }
    
    cmb_isScannerFullScreen = NO;
    [self performSelectorOnMainThread:@selector(updatePreviewContainerValues) withObject:nil waitUntilDone:YES];
}

RCT_EXPORT_METHOD(setPreviewContainerBelowStatusBar:(BOOL)arg){
    cmb_isScannerBelowStatusBar = arg;
    [self updatePreviewContainerValues];
}

RCT_EXPORT_METHOD(setPreviewContainerFullScreen){
    if (cmb_readerDevice != nil && param_deviceType == 1) {
        [cmb_readerDevice setCameraPreviewContainer:nil completion:^(NSError *error) {}];
    }
    
    cmb_isScannerFullScreen = YES;
}

RCT_EXPORT_METHOD(setStopScannerOnRotate:(BOOL)arg){
    cmb_stopScanningOnRotate = arg;
}

-(void)updatePreviewContainerValues {
    CGSize screenSize = [[UIScreen mainScreen] bounds].size;
    param_positionX =  position_xp /100 * screenSize.width;
    param_positionY =  (position_yp /100 * screenSize.height) + (cmb_isScannerBelowStatusBar ? UIApplication.sharedApplication.statusBarFrame.size.height : 0);
    
    param_sizeWidth = position_wp /100 * screenSize.width;
    param_sizeHeight = (position_hp /100 * screenSize.height) - (cmb_isScannerBelowStatusBar ? UIApplication.sharedApplication.statusBarFrame.size.height : 0);
    
    if (cmb_isScannerFullScreen) {
        // full screen
        [cmb_readerDevice setCameraPreviewContainer:nil completion:^(NSError *error) {}];
    } else {
        // partial view
        [cmb_readerDevice setCameraPreviewContainer:scannerView completion:^(NSError *error) {
            [self updateScannerViewPosition];
        }];
    }
}

-(void) addScannerView {
    if (!scannerView) {
        scannerView = [UIView new];
        [scannerView setTag:7639];
        [scannerView setClipsToBounds:YES];
    }
    [self updateScannerViewPosition];

    if (scannerView.superview) {
        [scannerView removeFromSuperview];
    }
    
    if (![UIApplication.sharedApplication.keyWindow.rootViewController.view viewWithTag:7639]) {
        [UIApplication.sharedApplication.keyWindow.rootViewController.view addSubview:scannerView];
    }
}

-(void)updateScannerViewPosition {
    if (scannerView) {
        [scannerView setFrame:CGRectMake(param_positionX, param_positionY, param_sizeWidth, param_sizeHeight)];
    }
}

-(void) removeScannerView {
    if (!scannerView)
        return;

    if (scannerView.superview) {
        [scannerView removeFromSuperview];
    }
    scannerView = nil;
}

-(void) setScannerViewHidden:(NSNumber*) hidden {
    if (scannerView) {
        [scannerView setHidden:[hidden boolValue]];
    }
}

RCT_EXPORT_METHOD(setCameraMode:(int)arg)
{
    @try {
        param_cameraMode = arg;
    } @catch (NSException *exception) {
        param_cameraMode = 0;
    } @finally {
    }
}

RCT_EXPORT_METHOD(setPreviewOptions:(int)arg)
{
    @try {
        param_previewOptions = arg;
    } @catch (NSException *exception) {
        param_previewOptions = 0;
    } @finally {
    }
}

RCT_REMAP_METHOD(disconnect, disconnectResolver:(RCTPromiseResolveBlock)disconnectResolver disconnectRejecter:(RCTPromiseRejectBlock)disconnectRejecter)
{
    //    connectionStateDidChangeOfReaderEvent = cdvCommand.callbackId;
    if ([self isReaderInit:disconnectRejecter]) {
        [self disconnect];
        if (disconnectResolver) {
            disconnectResolver(@(YES));
        }
    }
}

-(void)disconnect{
    if (!NSThread.currentThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self disconnect];
        });
        return;
    }
    [cmb_readerDevice disconnect];
}

RCT_REMAP_METHOD(beep, beepResolver:(RCTPromiseResolveBlock)beepResolver beepRejecter:(RCTPromiseRejectBlock)beepRejecter)
{
    if ([self isReaderInit:beepRejecter]) {
        [cmb_readerDevice beep];
        if (beepResolver) {
            beepResolver(@(YES));
        }
    }
}

-(NSString*) stringFromSymbology:(CMBSymbology) symbology {
    switch (symbology) {
        case CMBSymbologyDataMatrix : return @"Data Matrix";
        case CMBSymbologyQR : return @"QR";
        case CMBSymbologyC128 : return @"Code 128";
        case CMBSymbologyUpcEan : return @"UPC/EAN";
        case CMBSymbologyC11 : return @"Code 11";
        case CMBSymbologyC39 : return @"Code 39";
        case CMBSymbologyC93 : return @"Code 93";
        case CMBSymbologyI2o5 : return @"Interleaved 2 of 5";
        case CMBSymbologyCodaBar : return @"Codabar";
        case CMBSymbologyEanUcc : return @"EAN-UCC";
        case CMBSymbologyPharmaCode : return @"Pharmacode";
        case CMBSymbologyMaxicode : return @"MaxiCode";
        case CMBSymbologyPdf417 : return @"PDF417";
        case CMBSymbologyMicropdf417 : return @"Micro PDF417";
        case CMBSymbologyDatabar : return @"Databar";
        case CMBSymbologyPlanet : return @"PLANET";
        case CMBSymbologyPostnet : return @"POSTNET";
        case CMBSymbologyFourStateJap : return @"Japan Post";
        case CMBSymbologyFourStateAus : return @"Australia Post";
        case CMBSymbologyFourStateUpu : return @"UPU";
        case CMBSymbologyFourStateImb : return @"IMB";
        case CMBSymbologyVericode : return @"VERICODE";
        case CMBSymbologyRpc : return @"RPC";
        case CMBSymbologyMsi : return @"MSI";
        case CMBSymbologyAzteccode : return @"AztecCode";
        case CMBSymbologyDotcode : return @"DotCode";
        case CMBSymbologyC25 : return @"C25";
        case CMBSymbologyC39ConvertToC32 : return @"C39 to C32";
        case CMBSymbologyOcr : return @"OCR";
        case CMBSymbologyFourStateRmc : return @"RMC";
        case CMBSymbologyTelepen : return @"Telepen";
            
        default:
        case CMBSymbologyUnknown : return @"Unknown";
            break;
    }
}

// READER CONNECTION AND APIS
- (IBAction)toggleScanner:(UIButton*)sender {
    if (cmb_isScannerScanning) {
        [self stopScan];
        [sender setTitle:@"START SCANNING" forState:UIControlStateNormal];
    }else{
        [self startScan];
        [sender setTitle:@"STOP SCANNING" forState:UIControlStateNormal];
    }
    cmb_isScannerScanning = !cmb_isScannerScanning;
}

-(void) toggleScannerWithBool:(BOOL) scan {
    if (!scan) {
        [self stopScan];
    }else{
        [self startScan];
    }
    cmb_isScannerScanning = scan;
}

-(void) startScan {
    [cmb_readerDevice.dataManSystem sendCommand:@"GET TRIGGER.TYPE" withCallback:^(CDMResponse *response) {
        if (response.status == DMCC_STATUS_NO_ERROR) {
            param_triggerType = [response.payload intValue];
        }
    }];
    [cmb_readerDevice startScanning];
    if (param_deviceType == 0) {
        [self sendEventWithName:@"scanningStateChangedEvent" body:@(YES)];
    }
}

-(void) stopScan {
    [cmb_readerDevice stopScanning];
    if (param_deviceType == 0) {
        [self sendEventWithName:@"scanningStateChangedEvent" body:@(NO)];
    }
}

-(void) disconnectReaderDevice {
    if (cmb_readerDevice != nil && cmb_readerDevice.connectionState != CMBConnectionStateDisconnected) {
        [cmb_readerDevice disconnect];
    }
}

// Observers
-(void)triggerObserverTriggered:(NSNotification *)notification {
    if (notification.object) {
        [self sendEventWithName:@"scanningStateChangedEvent" body:@([notification.object boolValue])];
        
        [self performSelectorOnMainThread:@selector(setScannerViewHidden:) withObject:[NSNumber numberWithBool:![notification.object boolValue]] waitUntilDone:NO];
    }
}

-(void)rotationObserverTriggered:(NSNotification *)notification {
    if (currentAppOrientation != [[UIApplication sharedApplication]statusBarOrientation]) {
        currentAppOrientation = [[UIApplication sharedApplication]statusBarOrientation];
        if (cmb_isScannerScanning && cmb_stopScanningOnRotate) {
            [self stopScan];
        }
        
        [self performSelectorOnMainThread:@selector(updatePreviewContainerValues) withObject:nil waitUntilDone:YES];
        [self performSelectorOnMainThread:@selector(updateScannerViewPosition) withObject:nil waitUntilDone:NO];
    }
}

- (NSArray<NSString *> *)supportedEvents
{
    return @[
             @"didReceiveReadResultFromReaderEvent",
             @"availabilityDidChangeOfReaderEvent",
             @"connectionStateDidChangeOfReaderEvent",
             @"scanningStateChangedEvent",
             @"cmbCommandCompletionEvent"
             ];
}

RCT_EXPORT_METHOD(getSupportedEventNames:(RCTResponseSenderBlock)callback)
{
    callback([self supportedEvents]);
}

RCT_EXPORT_METHOD(imageFromSVG:(NSString*)svg imageFromSVGResolver:(RCTPromiseResolveBlock)imageFromSVGResolver imageFromSVGRejecter:(RCTPromiseRejectBlock)imageFromSVGRejecter)
{
    @try {
        int svgWidth = 0;
        int svgHeight = 0;
        
        NSError *er;
        NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"<svg.*width=\"(.*)px\".*height=\"(.*)px\".*>" options:NSRegularExpressionCaseInsensitive error:&er];
        NSTextCheckingResult *regexMatch = [regex firstMatchInString:svg options:0 range:NSMakeRange(0, [svg length])];
        
        if (regexMatch && er == nil) {
            svgWidth = ([regexMatch rangeAtIndex:1].length>0)?[[svg substringWithRange:[regexMatch rangeAtIndex:1]] intValue]:0;
            svgHeight = ([regexMatch rangeAtIndex:2].length>0)?[[svg substringWithRange:[regexMatch rangeAtIndex:2]] intValue]:0;
        }
        
        CDMSVGParser* parser = [[CDMSVGParser alloc] initWithData:[svg dataUsingEncoding:NSUTF8StringEncoding]];
        CDMSVGData *svgData = [parser parse];
        CDMSVGRenderer* renderer = [[CDMSVGRenderer alloc] initWithSVGData:svgData];
        UIImage *svgImage = [renderer imageFromSVGWithSize:((svgWidth == 0 && svgHeight == 0) ? scannerView.bounds.size : CGSizeMake(svgWidth, svgHeight))
                                           backgroundImage:nil];
        
        imageFromSVGResolver([UIImagePNGRepresentation(svgImage) base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength]);
    } @catch (NSException *exception) {
        imageFromSVGRejecter(@"0", @"Failed to convert svg to image", nil);
    } @finally {
    }
}

UIAlertView *cmbsdk_connectionAlert;
RCT_EXPORT_METHOD(toggleConnectionAlert:(BOOL)arg){
    if (arg) {
        if (!cmbsdk_connectionAlert) {
            cmbsdk_connectionAlert = [UIAlertView.alloc initWithTitle:@"Connecting" message:@"Please wait..." delegate:nil cancelButtonTitle:nil otherButtonTitles:nil, nil];
            [cmbsdk_connectionAlert show];
        }
    } else {
        if (cmbsdk_connectionAlert) {
            [cmbsdk_connectionAlert dismissWithClickedButtonIndex:0 animated:YES];
            cmbsdk_connectionAlert = nil;
        }
    }
}

@end

