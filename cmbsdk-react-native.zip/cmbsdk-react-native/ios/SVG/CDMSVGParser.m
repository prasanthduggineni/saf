//
//  CDMSVGParser.m
//  CDMSVG
//
//  Created by Ferenc Knebl on 02/10/14.
//  Copyright (c) 2014 Cognex Corporation. All rights reserved.
//

#import "CDMSVGParser.h"
#import "CDMXMLParser.h"

@implementation CDMSVGParser {
    CDMXMLParser* parser;
}

- (id) initWithData:(NSData*)data {
    if (self = [super init]) {
        parser = [[CDMXMLParser alloc] initWithData:data];
    }
    
    return self;
}

- (id) initWithStream:(NSInputStream *)stream {
    if (self = [super init]) {
        parser = [[CDMXMLParser alloc] initWithStream:stream];
    }
    
    return self;
}

- (CDMSVGData*) parse {
    CDMXMLElement* root;
    
    if ((root = [parser rootElement])) {
        NSMutableArray* svgobjects = [NSMutableArray arrayWithCapacity:5];
        float width = [[[root attributes] valueForKey:@"width"] floatValue];
        float height = [[[root attributes] valueForKey:@"height"] floatValue];
        
        for (CDMXMLElement* g in [root children]) {
            if ([g.name isEqualToString:@"g"]) {
                NSString* strokeColorString = [[g attributes] valueForKey:@"stroke"];
                UIColor* strokeColor = [UIColor whiteColor];
                
                if (strokeColorString && [strokeColorString length] > 0) {
                    strokeColor = [self parseColorFromHex: strokeColorString];
                }
                
                for (CDMXMLElement* polyobj in [g children]) {
                    @try {
                        if ([polyobj.name isEqualToString:@"polygon"]) {
                            CDMSVGPolygon* poly = [self parsePolygon:polyobj];
                            poly.strokeColor = strokeColor;
                            [svgobjects addObject:poly];
                        } else if ([polyobj.name isEqualToString:@"text"]) {
                            CDMSVGText* text = [self parseText:polyobj];
                            text.textColor = strokeColor;
                            [svgobjects addObject:text];
                        } else if ([polyobj.name isEqualToString:@"line"]) {
                            CDMSVGLine* line = [self parseLine:polyobj];
                            line.strokeColor = strokeColor;
                            [svgobjects addObject:line];
                        }
                    }@catch (NSException *exception) {
                        NSLog(@"Failed to parse element %@", [polyobj description]);
                    }
                    @finally {
                        
                    }
                }
            }
        }
        
        CDMSVGData* svg = [[CDMSVGData alloc] initWithObjects:svgobjects];
        svg.size = CGSizeMake(width, height);
        
        return svg;
    } else {
        NSLog(@"Failed to parse SVG XML, error: %@", parser.parseError);
        
        self.parseError = parser.parseError;
    }
    
    return nil;
}

#pragma mark - parser

- (CDMSVGPolygon*) parsePolygon:(CDMXMLElement*)obj {
    CDMSVGPolygon* poly = [[CDMSVGPolygon alloc] init];
    NSArray* pointPairs = [[[obj attributes] valueForKey:@"points"] componentsSeparatedByString:@" "];
    poly.path = [UIBezierPath bezierPath];
    
    for (NSString* pointPair in pointPairs) {
        NSArray* pparr = [pointPair componentsSeparatedByString:@","];
        if (pparr.count == 2) {
            CGPoint point = CGPointMake([pparr[0] floatValue], [pparr[1] floatValue]);
            if (poly.path.empty)
                [poly.path moveToPoint: point];
            else
                [poly.path addLineToPoint: point];
        }
    }
    
    [poly.path closePath];
    
    poly.path.lineWidth = 2.0f;
    
    return poly;
}

- (CDMSVGText*) parseText:(CDMXMLElement*)obj {
    CDMSVGText* text = [[CDMSVGText alloc] init];
    text.text = [obj value];
    float x = [[[obj attributes] valueForKey:@"x"] floatValue];
    float y = [[[obj attributes] valueForKey:@"y"] floatValue];
    text.position = CGPointMake(x, y);
    text.fontSize = [[[obj attributes] valueForKey:@"font-size"] floatValue];
    
    if (text.fontSize == 0)
        text.fontSize = 24.0f;
    
    return text;
}

- (CDMSVGLine*) parseLine:(CDMXMLElement*)obj {
    CDMSVGLine* line = [[CDMSVGLine alloc] init];
    NSString *x1 = [obj.attributes valueForKey:@"x1"];
    NSString *y1 = [obj.attributes valueForKey:@"y1"];
    NSString *x2 = [obj.attributes valueForKey:@"x2"];
    NSString *y2 = [obj.attributes valueForKey:@"y2"];
    
    if (x1 && x2 && y1 && y2) {
        CGPoint startingPoint = CGPointMake(x1.floatValue, y1.floatValue);
        CGPoint endingPoint = CGPointMake(x2.floatValue, y2.floatValue);
    
        line.path = [UIBezierPath bezierPath];
        
        [line.path moveToPoint: startingPoint];
        [line.path addLineToPoint: endingPoint];
    }
    
    NSString *strokeWidth = [obj.attributes valueForKey:@"stroke-width"];
    line.path.lineWidth = strokeWidth ? strokeWidth.floatValue : 2.0f;
    
    return line;
}

- (UIColor*)parseColorFromHex:(NSString*)hexValue {
    unsigned rgbValue = 0;
    NSScanner *scanner = [NSScanner scannerWithString:hexValue];
    
    [scanner setScanLocation:1];
    [scanner scanHexInt:&rgbValue];
    
    return [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0];
}

@end
