//
//  CDMSVGDrawer.m
//  CDMSVG
//
//  Created by Ferenc Knebl on 02/10/14.
//  Copyright (c) 2014 Cognex Corporation. All rights reserved.
//

#import "CDMSVGRenderer.h"

@implementation CDMSVGRenderer

- (id) initWithSVGData:(CDMSVGData*)svgdata {
    if (self = [super init]) {
        self.svgData = svgdata;
    }
    
    return self;
}

- (void) drawInContext:(CGContextRef)ctx {
    NSStringDrawingContext *drawingContext = [[NSStringDrawingContext alloc] init];
    drawingContext.minimumScaleFactor = 0.5; // Half the font size
    
    for (id<SVGObject> obj in self.svgData.objects) {
        if ([obj isKindOfClass:[CDMSVGPolygon class]]) {
            [self drawPolygon:(CDMSVGPolygon*)obj withContext:ctx];
        } else if ([obj isKindOfClass:[CDMSVGText class]]) {
            [self drawText:(CDMSVGText*)obj withStringDrawingContext:drawingContext];
        } else if ([obj isKindOfClass:[CDMSVGLine class]]) {
            [self drawLine:(CDMSVGLine*)obj withContext:ctx];
        }
    }
}

- (UIImage*) imageFromSVGWithSize:(CGSize)size backgroundImage:(UIImage*)bgimg {
    if (self.svgData) {
        CGFloat svgAspectRatio = self.svgData.size.width/self.svgData.size.height;
        CGFloat imageAspectRatio = size.width/size.height;
        
        CGFloat scaleFactor = 1.0;
        if (svgAspectRatio > imageAspectRatio) {
            // Width is limiting factor
            scaleFactor = size.width/self.svgData.size.width;
        } else {
            // Height is limiting factor
            scaleFactor = size.height/self.svgData.size.height;
        }
        CGAffineTransform scaleTransform = CGAffineTransformIdentity;
        scaleTransform = CGAffineTransformScale(scaleTransform, scaleFactor, scaleFactor);
        scaleTransform = CGAffineTransformTranslate(scaleTransform, 0, 0);
        
        UIGraphicsBeginImageContext(size);
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        if (bgimg)
            [bgimg drawAtPoint:CGPointZero];
        
        CGContextConcatCTM(context, scaleTransform);
        
        [self drawInContext:context];
        
        UIImage* result = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        return result;
    } else {
        return nil;
    }
}

#pragma mark - drawing

- (void) drawPolygon:(CDMSVGPolygon*)poly withContext:(CGContextRef)ctx {
    //CGPathRef scaledPath = CGPathCreateCopyByTransformingPath(poly.path.CGPath,
    //                                                          &transform);
    //CGContextAddPath(ctx, poly.path.CGPath);
    //CGContextSetStrokeColorWithColor(ctx, poly.strokeColor.CGColor);
    //CGContextStrokePath(ctx);
    //CGPathRelease(scaledPath);
    
    [poly.strokeColor setStroke];
    [poly.path stroke];
}

- (void) drawText:(CDMSVGText*)text withStringDrawingContext:(NSStringDrawingContext*)ctx {
    NSDictionary *textAttributes = @{NSFontAttributeName: [UIFont systemFontOfSize:text.fontSize], NSForegroundColorAttributeName: text.textColor};
    
    [text.text drawAtPoint:text.position withAttributes:textAttributes];
}

- (void) drawLine:(CDMSVGLine*)line withContext:(CGContextRef)ctx {
    [line.strokeColor setStroke];
    [line.path stroke];
}

@end
