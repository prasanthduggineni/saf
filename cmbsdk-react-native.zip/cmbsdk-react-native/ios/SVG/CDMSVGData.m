//
//  CDMSVGData.m
//  CDMSVG
//
//  Created by Ferenc Knebl on 02/10/14.
//  Copyright (c) 2014 Cognex Corporation. All rights reserved.
//

#import "CDMSVGData.h"

@interface CDMSVGData()

@property (nonatomic) NSArray* objects;

@end

@implementation CDMSVGData

- (id) initWithObjects:(NSArray*)objects {
    if (self = [super init]) {
        self.objects = objects;
    }
    
    return self;
}

@end

@implementation CDMSVGPolygon

@end

@implementation CDMSVGText

@end

@implementation CDMSVGLine

@end
