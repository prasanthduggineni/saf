//
//  CDMSVGDrawer.h
//  CDMSVG
//
//  Created by Ferenc Knebl on 02/10/14.
//  Copyright (c) 2014 Cognex Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "CDMSVGData.h"

@interface CDMSVGRenderer : NSObject

@property CDMSVGData* svgData;

- (id) initWithSVGData:(CDMSVGData*)svgdata;

- (void) drawInContext:(CGContextRef)ctx;
- (UIImage*) imageFromSVGWithSize:(CGSize)size backgroundImage:(UIImage*)bgimg;

@end
