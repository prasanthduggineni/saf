//
//  CDMSVGParser.h
//  CDMSVG
//
//  Created by Ferenc Knebl on 02/10/14.
//  Copyright (c) 2014 Cognex Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CDMSVGData.h"

@interface CDMSVGParser : NSObject

@property NSError* parseError;

- (id) initWithData:(NSData*)data;
- (id) initWithStream:(NSInputStream*)stream;
- (CDMSVGData*) parse;

@end
