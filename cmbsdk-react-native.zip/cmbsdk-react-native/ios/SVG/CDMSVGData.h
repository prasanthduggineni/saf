//
//  CDMSVGData.h
//  CDMSVG
//
//  Created by Ferenc Knebl on 02/10/14.
//  Copyright (c) 2014 Cognex Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol SVGObject<NSObject>

@end

@interface CDMSVGPolygon : NSObject<SVGObject>

@property UIColor* strokeColor;
@property UIBezierPath* path;

@end

@interface CDMSVGText : NSObject<SVGObject>

@property UIColor* textColor;
@property NSString* text;
@property CGPoint position;
@property CGFloat fontSize;

@end

@interface CDMSVGLine : NSObject<SVGObject>

@property UIColor* strokeColor;
@property UIBezierPath* path;

@end

@interface CDMSVGData : NSObject

@property (nonatomic) CGSize size;
@property (nonatomic, readonly) NSArray* objects;

- (id) initWithObjects:(NSArray*)objects;

@end
