//
//  RNCmbSdkHelper.h
//  RNCmbSdk
//
//  Created by Zhivko Manchev on 4/25/19.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol RCTCmbSdkObserverDelegate
- (void) rotationObserverTriggered:(NSNotification*) notification;
- (void) triggerObserverTriggered:(NSNotification*) notification;
@end

@interface RCTCmbSdkHelper : NSObject
@property (nonatomic, weak) id <RCTCmbSdkObserverDelegate> delegate;

- (void) startObserving;
- (void) stopObserving;
@end

NS_ASSUME_NONNULL_END
