//
//  CNMFlashPacket.h
//  CogNamer
//
//  Created by Krisztian Gyuris on 26/09/14.
//  Copyright (c) 2014 Cognex Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CNMCogNamerPacket.h"

@interface CNMFlashPacket : CNMCogNamerPacket

- (id)initWithMacAddress:(NSData*)macAddress;

@end
