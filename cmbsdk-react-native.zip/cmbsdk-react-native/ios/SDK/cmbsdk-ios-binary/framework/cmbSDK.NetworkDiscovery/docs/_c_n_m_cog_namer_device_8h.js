var _c_n_m_cog_namer_device_8h =
[
    [ "CNMCogNamerDevice", "interface_c_n_m_cog_namer_device.html", "interface_c_n_m_cog_namer_device" ],
    [ "EthernetDeviceScope", "_c_n_m_cog_namer_device_8h.html#a6403811adf407048391241d8cdc76d7a", [
      [ "kLinkLocal", "_c_n_m_cog_namer_device_8h.html#a6403811adf407048391241d8cdc76d7aa636239db071dcc499be467d77f220598", null ],
      [ "kSubnetLocal", "_c_n_m_cog_namer_device_8h.html#a6403811adf407048391241d8cdc76d7aa48f03dbd864f1e8356393d34d5d94b00", null ],
      [ "kRemoteSubnet", "_c_n_m_cog_namer_device_8h.html#a6403811adf407048391241d8cdc76d7aa7f549dfc4c4160107942821808e6039d", null ],
      [ "kUnknown", "_c_n_m_cog_namer_device_8h.html#a6403811adf407048391241d8cdc76d7aa8e792321b79a4aa90e75bd3fcc2e4141", null ]
    ] ]
];