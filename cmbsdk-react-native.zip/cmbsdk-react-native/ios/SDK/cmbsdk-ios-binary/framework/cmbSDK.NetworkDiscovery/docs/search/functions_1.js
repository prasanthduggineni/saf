var searchData=
[
  ['devicediscovered_3a',['deviceDiscovered:',['../protocol_c_n_m_system_discovered_delegate_01-p.html#ac5c8ced163fafa8374cc623febbf8fd9',1,'CNMSystemDiscoveredDelegate -p']]]
];
