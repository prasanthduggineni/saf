var files_dup =
[
    [ "CNMCogNamerDevice.h", "_c_n_m_cog_namer_device_8h.html", "_c_n_m_cog_namer_device_8h" ],
    [ "CNMEthernetSystemDiscoverer.h", "_c_n_m_ethernet_system_discoverer_8h.html", [
      [ "CNMEthernetSystemDiscoverer", "interface_c_n_m_ethernet_system_discoverer.html", "interface_c_n_m_ethernet_system_discoverer" ]
    ] ],
    [ "CNMSystemDiscoveredDelegate.h", "_c_n_m_system_discovered_delegate_8h.html", [
      [ "<CNMSystemDiscoveredDelegate >", "protocol_c_n_m_system_discovered_delegate_01-p.html", "protocol_c_n_m_system_discovered_delegate_01-p" ]
    ] ]
];