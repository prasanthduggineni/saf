var searchData=
[
  ['name',['name',['../interface_c_n_m_cog_namer_device.html#a33ab3c3de944d234c45cc163e45a6763',1,'CNMCogNamerDevice']]]
];
