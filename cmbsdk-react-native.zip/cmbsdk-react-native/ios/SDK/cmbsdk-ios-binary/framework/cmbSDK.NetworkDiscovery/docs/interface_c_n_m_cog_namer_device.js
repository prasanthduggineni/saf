var interface_c_n_m_cog_namer_device =
[
    [ "defaultGateway", "interface_c_n_m_cog_namer_device.html#a04194d6fb9dd9ad2e5916c77bb78e3f3", null ],
    [ "deviceType", "interface_c_n_m_cog_namer_device.html#a8afa6ef690a69d34c162d0fe73a63fda", null ],
    [ "dnsServer", "interface_c_n_m_cog_namer_device.html#adef34d28b19922b6a7e0f374cc808a3a", null ],
    [ "domain", "interface_c_n_m_cog_namer_device.html#a96ed15722f6ba62a7cee992f6f2409fe", null ],
    [ "firmwareVersion", "interface_c_n_m_cog_namer_device.html#a4ee19790e0229a1f8ba74bb463b9107d", null ],
    [ "ipAddress", "interface_c_n_m_cog_namer_device.html#a5050858f4eb17a80533605887a8e4799", null ],
    [ "isDhcpEnabled", "interface_c_n_m_cog_namer_device.html#a15485bfe78cab3862f88a288e2215d1c", null ],
    [ "isLinkLocalIP", "interface_c_n_m_cog_namer_device.html#a04ab360663fc4b0637771985cfa29619", null ],
    [ "macAddress", "interface_c_n_m_cog_namer_device.html#a771d7dae85245af8957dae19c7ecd4f1", null ],
    [ "macAddressFormatted", "interface_c_n_m_cog_namer_device.html#a4b93e631be1b50b6c6d0a93083da3193", null ],
    [ "modelNumber", "interface_c_n_m_cog_namer_device.html#ad143c934f875f9d5b20ef1a4ac6d97c5", null ],
    [ "name", "interface_c_n_m_cog_namer_device.html#a33ab3c3de944d234c45cc163e45a6763", null ],
    [ "port", "interface_c_n_m_cog_namer_device.html#a5c8d1993e8b09a62f91e4631e53f4b03", null ],
    [ "scope", "interface_c_n_m_cog_namer_device.html#a651818a4e4b7b147e711d851586eb97b", null ],
    [ "serialNumber", "interface_c_n_m_cog_namer_device.html#a43429bf3707d150e4c5f5ec7a69cd358", null ],
    [ "subnetMask", "interface_c_n_m_cog_namer_device.html#a68392a2324fd1e01336f9abdc5122e63", null ],
    [ "systemDescription", "interface_c_n_m_cog_namer_device.html#acdc1e2e40ee3bb07a37b11ee96a902a5", null ],
    [ "type", "interface_c_n_m_cog_namer_device.html#af255b820aee3dc91b66319d2fdcba763", null ]
];