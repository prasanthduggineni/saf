var searchData=
[
  ['type',['type',['../interface_c_n_m_cog_namer_device.html#af255b820aee3dc91b66319d2fdcba763',1,'CNMCogNamerDevice']]]
];
