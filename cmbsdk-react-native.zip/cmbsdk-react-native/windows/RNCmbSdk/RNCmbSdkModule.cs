using ReactNative.Bridge;
using System;
using System.Collections.Generic;
using Windows.ApplicationModel.Core;
using Windows.UI.Core;

namespace Cmb.Sdk.RNCmbSdk
{
    /// <summary>
    /// A module that allows JS to share data.
    /// </summary>
    class RNCmbSdkModule : NativeModuleBase
    {
        /// <summary>
        /// Instantiates the <see cref="RNCmbSdkModule"/>.
        /// </summary>
        internal RNCmbSdkModule()
        {

        }

        /// <summary>
        /// The name of the native module.
        /// </summary>
        public override string Name
        {
            get
            {
                return "RNCmbSdk";
            }
        }
    }
}
