export class CMBReader {

}

CMBReader.DEVICE_TYPE = {
	// Use a MX-1xxx device for scanning
	MXReader : 0,
	// Use the mobile's built in camera for scanning
	Camera : 1
}

CMBReader.SYMBOLOGY = {
	Unknown : 0,
	DataMatrix : 1,
	QR : 2,
	C128 : 3,
	UpcEan : 4,
	C11 : 5,
	C39 : 6,
	C93 : 7,
	I2o5 : 8,
	CodaBar : 9,
	EanUcc : 10,
	PharmaCode : 11,
	Maxicode : 12,
	Pdf417 : 13,
	Micropdf417 : 14,
	Databar : 15,
	Planet : 16,
	Postnet : 17,
	FourStateJap : 18,
	FourStateAus : 19,
	FourStateUpu : 20,
	FourStateImb : 21,
	Vericode : 22,
	Rpc : 23,
	Msi : 24,
	Azteccode : 25,
	Dotcode : 26,
	C25 : 27,
	C39ConvertToC32 : 28,
	Ocr : 29,
	FourStateRm : 30
}

CMBReader.SYMBOLOGY_NAME = {
	Unknown : "Unknown", 
	DataMatrix : "DataMatrix", 
	QR : "QR", 
	C128 : "C128", 
	UpcEan : "UpcEan", 
	C11 : "C11", 
	C39 : "C39", 
	C93 : "C93", 
	I2o5 : "I2o5", 
	CodaBar : "CodaBar", 
	EanUcc : "EanUcc", 
	PharmaCode : "PharmaCode", 
	Maxicode : "Maxicode", 
	Pdf417 : "Pdf417", 
	Micropdf417 : "Micropdf417", 
	Databar : "Databar", 
	Planet : "Planet", 
	Postnet : "Postnet", 
	FourStateJap : "FourStateJap", 
	FourStateAus : "FourStateAus", 
	FourStateUpu : "FourStateUpu", 
	FourStateImb : "FourStateImb", 
	Vericode : "Vericode", 
	Rpc : "Rpc", 
	Msi : "Msi", 
	Azteccode : "Azteccode", 
	Dotcode : "Dotcode", 
	C25 : "C25", 
	C39ConvertToC32 : "C39ConvertToC32", 
	Ocr : "Ocr", 
	FourStateRm : "FourStateRm"
}

CMBReader.CONNECTION_STATE = {
    //The CDMDataManSystem object is not connected to any remote system.
	Disconnected : 0,
    // The CDMDataManSystem object is in the process of establishing a connection to a remote system.
	Connecting : 1,
    // The CDMDataManSystem object is connected to a remote system.
	Connected : 2,
    // The CDMDataManSystem object is in the process of disconnecting from a remote system.
	Disconnecting : 3,
    // The CDMDataManSystem object's connection state is unavailable.
	Unavailable : 4
}

CMBReader.AVAILABILITY = {
	Unknown : 0,
    Available : 1,
    Unavailable : 2
}

CMBReader.EVENT = {
	// Event is called when a barcode is scanned.
	// Returns CMBReadResults object, see https://cmbdn.cognex.com/cmbSDK/programmers-reference-ios/html/interface_c_m_b_read_results.html
	ReadResultReceived : "didReceiveReadResultFromReaderEvent",
	// Event is called when a MX Device availability changes (MX-1xxx turns on/off or cable gets plugged/unplugged). 
	// returns CMBReader.AVAILABILITY
	AvailabilityChanged : "availabilityDidChangeOfReaderEvent",
	// Event is called when the readerDevice connection state changes.
	// returns CMBReader.CONNECTION
	ConnectionStateChanged : "connectionStateDidChangeOfReaderEvent",
	// Event is called when the scanner starts using the startScanner function or "TRIGGER ON" DMCC, or stops.
	// returns boolean: true if scanner stars, false if stops
	ScanningStateChanged : "scanningStateChangedEvent",
	// Event is called when a DMCC completes.
	// returns JSONObject containing: commandID(String), success(boolean), message(String, returned only when an error occurs), response(String), eventType(String)
	CommandCompleted : "cmbCommandCompletionEvent"
}

CMBReader.CAMERA_MODE = {
     // Use camera with no aimer. Preview is on, illumination is available.
    NoAimer : 0,
    // Use camera with a basic aimer (e.g., StingRay). Preview is off, illumination is not available.
    PassiveAimer : 1,
    // Use camera with an active aimer (e.g., MX-100). Preview is off, illumination is available. Not available on Android
    ActiveAimer : 2,
    // Use mobile device front camera. Preview is on, illumination is not available.
    FrontCamera : 3
}

CMBReader.CAMERA_PREVIEW_OPTION = {
	// Use defaults (no overrides).
    Defaults : 0,
	// Disable zoom feature (removes zoom button from preview).
    NoZoomBtn : 1,
	// Disable illumination (removes illumination button from preview).
    NoIllumBtn : 2,
	// Enables the simulated hardware trigger (the volume down button).
    HwTrigger : 4,
	// When scanning starts, the preview is displayed but decoding is paused until a trigger (either the on screen button or the volume down button, if enabled) is pressed.
    Paused : 8,
	// Force the preview to be displayed, even if off by default (e.g., when using PassiveAimer or ActiveAimer).
    AlwaysShow : 16,
	// Affects only ActiveAimer, reads the settings from the ActiveAimer after the app has been resumed.
    PessimisticCaching : 32,
	// Use higher resolution if the device supports it. Default is 1280x720, with this param 1920x1080 will be used.
    HighResolution : 64,
	// Use higher framerate if the device supports it. Default is 30 FPS, with this param 60 FPS will be used.
    HighFramerate : 128
}

CMBReader.RESULT_PARSER = {
    None : 0,
    Auto : 1,
    AAMVA : 2,
    GS1 : 3,
    HIBC : 4,
    ISBT128 : 5,
    IUID : 6,
    SCM : 7
}


