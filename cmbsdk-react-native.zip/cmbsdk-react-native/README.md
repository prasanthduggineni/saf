# React-Native Cognex Mobile Barcode Scanner SDK

## Getting started

`$ npm install cmbsdk-react-native --save`

### Mostly automatic installation

`$ react-native link cmbsdk-react-native`


### Import the cmbsdk react-native component in your app

```
import { CMBReader, cmbComponent } from 'cmbsdk-react-native';
```

## Documentation and integration info

Install React Native if you haven't already:

[React-Native Getting Started](https://facebook.github.io/react-native/docs/getting-started.html)


React-Native cmbSDK integration info:

[React-Native cmbSDK Documentation](https://cmbdn.cognex.com/knowledge/react-nat)


## React Native cmbSDK component
API Methods:
#### (Promise) loadScanner(deviceType,[callback])

```javascript
/*   @return 
{
    const (string)action : the taken action (will always return LOAD READER)
    (string)  result : the message from the server
    (bool)    status : if the reader was loaded it will return true
    (string)  err    : the string error if an error was thrown
    (int)     type   : the type of the device that we connected to [0,1]
    (string)  name   : the name of the type of device DEVICES[type]
}
*/            
```

To get a scanner up and running, the first thing to do, is to call the **loadScanner()** method. It expects a device type and a callback function as a second param. The callback function is wrapped within a Promise and it is returned as one. This method does not connect to the Reader Device. We need to call **connect()** in the callback to actually connect to the Reader Device

```javascript
cmbComponent.loadScanner(CMBReader.DEVICE_TYPE.MXReader).then((response) => {
	cmbComponent.getAvailability().then((response) => {
		if (response == CMBReader.AVAILABILITY.Available) {
			connectReader();
		}
	}).catch((rejecter) => {
	})
});
```


#### (Promise) connect([callback]) 
```javascript
/*   @return 
    (promise)  {
        status : boolean, if connection succeded true if not false
        err : string , if status false err will not be null
    }
*/ 
```

The result from the connect() method is returned as a Promise and it will return the result of the connection attempt:

```javascript
cmbComponent.connect().then((connectMethodResult) => {
	// do something after a connection has been established
	configureReader();
}).catch((failure) => {
	console.log("CMB - connectReader failed: "+JSON.stringify(failure))
});
```
There is a Event Listener for the connection status of the ReaderDevice, namely the **CMBReader.EVENT.ConnectionStateChanged** event which is explained in more detail below.


#### (Promise) disconnect([callback])
```javascript
/*   @return 
    (promise)  {
        status : boolean, if connection succeded true if not false
        err : string , if status false err will not be null
    }
*/ 
```

Just as there is **connect()**, there is a **disconnect()** method that does the opossite of **connect()** : 

```javascript
cmbComponent.disconnect();
```

Similarly to **connect()**, **disconnect()** too triggers the **CMBReader.EVENT.ConnectionStateChanged** event.

#### (void) startScanning([callback]); (void) stopScanning([callback])
```javascript
/*   @return Promise
      (bool) value of the Scanner Activity (true if the command was successful, false otherwise ex: if readerDevice not initialized)
*/ 
```

To start / stop the scanning process, we use these methods. 
They take a promise as a parameter, which will be resolved if the command was successful (the scanning has started or stopped) or rejected otherwise (if there is no active ReaderDevice initialized or isn't connected). 

After starting the scanner and scanning a barcode, the scan result triggers the **CMBReader.EVENT.ReadResultReceived** event.

#### (void) setSymbologyEnabled(symbol, on_off,commandID)

Once there is a connection to the Reader, we can enable symbologies by calling **setSymbologyEnabled()**. 
It expects a int value of the symbol to be enabled, a boolean for ON/OFF, and a String for the commandID for handling the command result.

This method triggers the **CMBReader.EVENT.CommandCompleted** event, whose result contains the *commandID* string from the third parameter, so that you know which commands have succeeded and which have failed in the event result.

```javascript
cmbComponent.setSymbology(CMBReader.SYMBOLOGY.QR, true, CMBReader.SYMBOLOGY_NAME.QR);
```
#### (void) isSymbologyEnabled(symbol,commandID)
To check if we have a symbol enabled, we use **isSymbologyEnabled()**. The result triggers the **CMBReader.EVENT.CommandCompleted** event, and it contains the *commandID* string from the second parameter, so that you know which commands have succeeded and which have failed in the event result.

```javascript
cmbComponent.isSymbologyEnabled(CMBReader.SYMBOLOGY.QR, CMBReader.SYMBOLOGY_NAME.QR);
```

#### (Promise) setLightsOn(lights_on, callback) ; (Promise) isLightsOn(callback)
```javascript
/**
@return A promise that contains the JSON object
{
  (string)  action  : the DMCC command that was invoked
  (bool)    status  : did it succeed or not, if an error happened it will be set to false
  (string)  err     : the error message if the action didn't complete
  (bool)  result    : the result of the taken action, in this case TRUE if the light was enabled, false if not
}
*/
```

If we want to enable the flash by default we can use **setLightsOn()** and to check if it is enabled with **isLightsOn()**
**setLightsOn()** and **isLightsOn()** both return a Promise.

#### (Promise) getConnectionState([callback])
```javascript
@return A promise that resolves with CMBReader.CONNECTION_STATE value of the reader's current connectionState

```

If you need to get the current connection state, **getConnectionState()** can be used

```javascript
cmbComponent.getConnectionState().then(function(connectionState){
  if (connectionState == CMBReader.CONNECTION_STATE.Connected) {
  		// reader is connected
  }
});
```


#### (void) setCameraMode(CMBReader.CAMERA_MODE)

To set how the camera will behave when we use CAMERA device as a barcode Reader we use:

```javascript
cmbComponent.setCameraMode(CMBReader.CAMERA_MODE)
/**
Use camera with no aimer. Preview is on, illumination is available.
CMBReader.CAMERA_MODE.NoAimer = 0,

Use camera with a basic aimer (e.g., StingRay). Preview is off, illumination is not available.
CMBReader.CAMERA_MODE.PassiveAimer = 1,

Use camera with an active aimer (e.g., MX-100). Preview is off, illumination is available.
CMBReader.CAMERA_MODE.ActiveAimer = 2,

Use mobile device front camera. Preview is on, illumination is not available.
CMBReader.CAMERA_MODE.FrontCamera = 3
*/
```

*Note:  It should be called BEFORE we call **loadScanner()** for it to take effect. Calling it after the scanner was loaded won't do anything if the scanner is loaded.*

#### (void) setPreviewContainerPositionAndSize([x,y,w,h])

```javascript
/*
  @param [x,y,w,h]
        x,y  : top left position
        w,h  : width and height of the rectangular in precentages of the full container
*/
```

Used only with the phone camera, sets the size and position of the camera preview screen.


Example:

```javascript
cmbComponent.setPreviewContainerPositionAndSize([0,0,100,50]);
//will set the preview to 0,0 and 100% width 50% height
```

#### (void) setPreviewContainerFullScreen()

Used only with the phone camera, sets the camera preview to start in full screen instead of partial view.


Example:

```javascript
cmbComponent.setPreviewContainerFullScreen();
//will set the camera preview to start in full screen when startScanning is called
```


#### (void) setPreviewContainerBelowStatusBar(boolean) - iOS Only

Used only with the phone camera on iOS, sets the camera preview partial view top axis to start below the status bar matching the Androids behavior.


Example:

```javascript
cmbComponent.setPreviewContainerBelowStatusBar(true);
cmbComponent.setPreviewContainerPositionAndSize([0,0,100,50]);
//will set the preview to 0,0 and 100% width 50% height. On iOS the partial view will be shown below the status bar.
```

```javascript
cmbComponent.setPreviewContainerBelowStatusBar(false);
cmbComponent.setPreviewContainerPositionAndSize([0,0,100,50]);
//will set the preview to 0,0 and 100% width 50% height. On iOS the partial view will start from the top of the screen, and will overlap the status bar.
```

#### (void) enableImage(enable_disable)

#### (void) enableImageGraphics(enable_disable)

To enable / disable result type returned as image use

```javascript
cmbComponent.enableImage(true);
```

Same for **enableImageGrapics()**.

```javascript
cmbComponent.enableImageGraphics(false);
```

#### (void) setParser(CMBReader.RESULT_PARSER)
Enable or disable parsing for scanned barcodes. <br>

Example:

```javascript
cmbComponent.setParser(CMBReader.RESULT_PARSER.GS1);
```

#### (void) setPreviewOptions(ORED VALUES OF CMBReader.CAMERA_PREVIEW_OPTION)

Set the overrided preview options. <br>
This function expects an integer that is a result of the ORed result of all the preview options that we want enabled.<br>
Doesn't return a value. <br>
Should be called BEFORE **loadScanner()** (same as cameraMode())<br>
Example:

```javascript
cmbComponent.setPreviewOptions(CMBReader.CAMERA_PREVIEW_OPTION.NoZoomBtn | CMBReader.CAMERA_PREVIEW_OPTION.NoIllumBtn);
```

#### (Promise) getDeviceBatteryLevel([callback])
```javascript
/*
@return A promise that contains the JSON object
{
    action  : the DMCC command that was invoked
    status  : did it succeed or not, if an error happened it will be set to false
    charge  : (int) the charge in percentage
    err     : the error message if the action didn't complete
}
*/
```

Helper method to show the battery levels of the connected device. Use it like this:


```javascript
cmbComponent.getDeviceBatteryLevel(function(result){
  console.log(JSON.stringify(result));
});
```

#### (Promise) resetConfig([callback])
```javascript
/*
@return A promise that contains the JSON object
{
  (string) action  : the DMCC command that was invoked
  (bool)   status  : did it succeed or not, if an error happened it will be set to false
  (string) err     : the error message if the action didn't complete and there is an error. default is null
  (bool)  result   : the result of the resetConfig action 
}
*/
```

To reset the configuration options we can use **resetConfig**

```javascript
cmbComponent.resetConfig(function(result){
  console.log(result);
})
```

#### (void) sendCommand(command, commandID)

Finally, all the methods can be replaced with sending DMCC strings to the READER device. For that we can use our API method **sendCommand**. It can be used to control the Reader completely with command strings. <br>
More on the command strings can be found [here](https://cmbdn.cognex.com/knowledge/-cognex-mobile-barcode-sdk-for-ios/appendix-a-dmcc-for-the-camera-reader/appendix-a-dmcc-for-the-camera-reader) or [here](https://cmbdn.cognex.com/knowledge/cognex-mobile-barcode-sdk-for-android/appendix-dmcc-for-the-camera-reader/appendix-dmcc-for-the-camera-reader)

Use it like this:

```javascript
cmbComponent.sendCommand("SET SYMBOL.POSTNET OFF", "postnetCommandID"); 
```

## Events
The React native cmbSDK module emits Events that can be used in the js application. These should be added in the componentDidMount function, and removed in componentWillUnmount (see [React component lifecycle](https://reactjs.org/docs/react-component.html)).

First create the event emitter:

```javascript
import NativeModules.NativeEventEmitter;
const scannerListener = new NativeEventEmitter(cmbComponent);

```
and then add listeners for each event you want to handle:

```javascript
scannerListener.addListener(
      CMBReader.EVENT.ReadResultReceived,
      (result) => {
        if (result.goodRead == true){
	        Alert.alert(
	          result.symbologyString,
	          result.readString
	        );
        }
      }
    );

```

Here are all the events that the cmbSDK module can emit:

```bash
CMBReader.EVENT.ReadResultReceived
CMBReader.EVENT.AvailabilityChanged
CMBReader.EVENT.ConnectionStateChanged
CMBReader.EVENT.ScanningStateChanged
CMBReader.EVENT.CommandCompleted
```
        

#### CMBReader.EVENT.ReadResultReceived
This event is triggered whenever a scan result is received. The result is a CMBReadResults object (see [CMBReadResults class reference](https://cmbdn.cognex.com/cmbSDK/programmers-reference-ios/html/interface_c_m_b_read_results.html)).

#### CMBReader.EVENT.AvailabilityChanged
This event is triggered when the availability of the ReaderDevice changes (example: when the MX Mobile Terminal has connected or disconnected the cable, or has turned on or off). The result is an int containing the availability information.

#### CMBReader.EVENT.ConnectionStateChanged
This event is triggered when the connection state of the ReaderDevice changes. The result is an int containing the connection information.

#### CMBReader.EVENT.ScanningStateChanged
This event is triggered when the scanner state of the ReaderDevice changes. The result is a boolean that is true if the scanning started, or false if it stopped.

#### CMBReader.EVENT.CommandCompleted
This event is triggered when a ReaderDevice command has completed. The result contains the following information:

```bash
commandID (String, the same param that was used to send the command)
eventType (String, ex: isSymbologyEnabled)
command (String, the command that was sent)
success (Boolean)
status (nullable, int, command status (See CDMResponse.h))
message (nullable, String, command payload)
image (nullable, base64 String representation of the scan image)
response (nullable, Boolean, command response, ex: isSymbologyEnabled will return true/false here)
```



### License Key(s)


**IMPORTANT**

Usage of the Cordova plugin with an MX device is free, but if you want to utilize the CAMERA DEVICE (scan with the smartphone camera), you need to obtain a license from [CMBDN](https://cmbdn.cognex.com). 

The Reader still works without a license, but results are randomly masked with * chars.

It's free to register and you can obtain a 30 day trial license key. Once the key is obtained, depending on the platform we either set it inside the android manifest file:

![AndroidManifest.xml](https://user-images.githubusercontent.com/226620/34641591-ba201cda-f306-11e7-9a08-28b42ed5d1ee.png)

or inside the iOS plist file for iOS

![iOS Plist](https://user-images.githubusercontent.com/226620/34641700-6616afd0-f308-11e7-8555-11411ed88b74.png)

Trial keys are not bound to the app bundle name / package name, but they only last for 30 days. 
Production keys are bound to the bundle name of the app, and this needs to be taken into account when you setup the license key.

On the image, we show the bundle Identifier on the iOS platform
![bundle name](https://user-images.githubusercontent.com/226620/34641799-cecb5b7e-f309-11e7-906c-7b2f3310915d.png)

> Android minSDK version needs to be bumped to 19

```html

    <uses-sdk android:minSdkVersion="19" android:targetSdkVersion="26" />
    
```

