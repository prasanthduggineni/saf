
package com.cmb;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Point;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.Base64;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.OrientationEventListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import androidx.annotation.RequiresApi;

import com.caverock.androidsvg.SVG;
import com.cognex.dataman.sdk.ConnectionState;
import com.cognex.dataman.sdk.DataManSystem;
import com.cognex.dataman.sdk.DmccResponse;
import com.cognex.mobile.barcode.sdk.ReadResult;
import com.cognex.mobile.barcode.sdk.ReadResults;
import com.cognex.mobile.barcode.sdk.ReaderDevice;
import com.cognex.mobile.barcode.sdk.ReaderDevice.ResultParser;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.LifecycleEventListener;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.Field;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RCTCmbSdkModule extends ReactContextBaseJavaModule
        implements
        ReaderDevice.ReaderDeviceListener {

    private final ReactApplicationContext reactContext;

    public RCTCmbSdkModule(ReactApplicationContext reactContext) {
        super(reactContext);
        this.reactContext = reactContext;
    }

    @Override
    public String getName() {
        return "RCTCmbSdk";
    }

    // RNCmbSDK Bridge
    private int param_cameraMode = 0;
    private int param_previewOptions = 0;
    private float param_positionX = 0;
    private float param_positionY = 0;
    private float param_sizeWidth = 100;
    private float param_sizeHeight = 50;
    private int param_triggerType = 2;
    private int param_deviceType = 0;

    private boolean param_isScannerFullScreen = false;
    private boolean cmb_stopScanningOnRotate = true;

    private ReaderDevice readerDevice;

    private boolean isScanning = false;
    private AlertDialog connectingAlert;

    // USB Listener, no need for conditional code
    private static boolean listeningForUSB = false;
    private static boolean listeningForOrientation = false;
    private OrientationEventListener mOrientationEventListener;

    public enum DeviceType {MX_1000, MOBILE_DEVICE}

    private static final DeviceType[] deviceTypeValues = DeviceType.values();

    private static final ReaderDevice.Symbology[] symbologyValues = ReaderDevice.Symbology.values();

    public static ReaderDevice.Symbology symbologyFromInt(int i) {
        return symbologyValues[i];
    }

    private static DeviceType deviceTypeFromInt(int i) {
        return deviceTypeValues[i];
    }

    // initial scanner view position in %
    private float position_xp = 0;
    private float position_yp = 0;
    private float position_wp = 100;
    private float position_hp = 50;
    private final ReaderDevice.Symbology[] symbologies = ReaderDevice.Symbology.values();

    private LifecycleEventListener lifecycleEventListener;
    private static final boolean DEBUG_LOGS = false;

    //Custom API methods
    @ReactMethod
    private void loadScanner(final int deviceType, final Promise promise) {
        param_deviceType = deviceType;

        getCurrentActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (listeningForUSB) {
                    readerDevice.stopAvailabilityListening();
                    listeningForUSB = false;
                }

                removeScannerView();

                if (readerDevice != null && readerDevice.getConnectionState() == ConnectionState.Connected) {
                    emitEvent(CMBEvent.connectionStateDidChangeOfReaderEvent, (ConnectionState.Disconnected.ordinal()));

                    readerDevice.disconnect();

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            loadScanner(deviceType, promise);
                        }
                    }, 10);

                    return;
                }

                addScannerView();
                if (deviceTypeFromInt(param_deviceType) == DeviceType.MOBILE_DEVICE) {
                    readerDevice = ReaderDevice.getPhoneCameraDevice(getCurrentActivity(), param_cameraMode, param_previewOptions
                            , param_isScannerFullScreen ? null : scannerView
                            , regKey);

                    updatePreviewContainerValues();
                } else {
                    readerDevice = ReaderDevice.getMXDevice(getCurrentActivity());
                    if (!listeningForUSB) {
                        readerDevice.startAvailabilityListening();
                        listeningForUSB = true;
                    }
                }
                readerDevice.setReaderDeviceListener(RCTCmbSdkModule.this);
                readerDevice.enableImage(true);

                promise.resolve(null);
            }
        });
    }

    private ScannerViewContainer scannerView;

    private void removeScannerView() {
        if (scannerView == null) {
            return;
        }

        if (scannerView.getParent() != null) {
            ((ViewGroup) scannerView.getParent()).removeView(scannerView);
        }

        scannerView = null;
    }

    private void updateScannerViewPosition() {
        try {
            if (scannerView != null && scannerView.getLayoutParams() != null) {

                scannerView.getLayoutParams().width = Math.round(param_sizeWidth);
                scannerView.getLayoutParams().height = Math.round(param_sizeHeight);

                if (scannerView.getLayoutParams().getClass() == FrameLayout.LayoutParams.class) {
                    FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) scannerView.getLayoutParams();
                    params.setMargins((int) param_positionX, (int) param_positionY, 0, 0);
                    params.gravity = Gravity.TOP;

                    scannerView.setLayoutParams(params);
                } else {
                    Class c = scannerView.getLayoutParams().getClass();
                    Field field = null;

                    try {
                        field = c.getDeclaredField("x");
                    } catch (Exception ignored) {
                    }

                    try {
                        field = c.getDeclaredField("leftMargin");
                    } catch (Exception ignored) {
                    }

                    try {
                        field = c.getDeclaredField("marginLeft");
                    } catch (Exception ignored) {
                    }

                    try {
                        field.setAccessible(true);
                        field.set(scannerView.getLayoutParams(), Math.round(param_positionX));
                    } catch (Exception ignored) {
                    }

                    try {
                        field = c.getDeclaredField("y");
                    } catch (Exception ignored) {
                    }
                    try {
                        field = c.getDeclaredField("topMargin");
                    } catch (Exception ignored) {
                    }
                    try {
                        field = c.getDeclaredField("marginTop");
                    } catch (Exception ignored) {
                    }

                    try {
                        field.setAccessible(true);
                        field.set(scannerView.getLayoutParams(), Math.round(param_positionY));
                    } catch (Exception ignored) {
                    }
                }

            } else {
                ViewGroup.MarginLayoutParams scannerViewParams = new ViewGroup.MarginLayoutParams(Math.round(param_sizeWidth), Math.round(param_sizeHeight));
                scannerViewParams.leftMargin = Math.round(param_positionX);
                scannerViewParams.topMargin = Math.round(param_positionY);
                scannerView.setLayoutParams(scannerViewParams);
            }

        } catch (Exception ignored) {
        }
    }

    private void addScannerView() {
        if (scannerView == null) {
            scannerView = new ScannerViewContainer(getCurrentActivity()) {
                @Override
                protected void onConfigurationChanged(Configuration newConfig) {
                    if (deviceTypeFromInt(param_deviceType) == DeviceType.MOBILE_DEVICE) {
                        getCurrentActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updatePreviewContainerValues();

                                if (isScanning && cmb_stopScanningOnRotate) {
                                    // Stop scanner after delay, because surfaceChanged can be triggered after surfaceDestroyed and can cause problems
                                    new Handler().postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            stopScanning(null);
                                        }
                                    }, 200);
                                }
                            }
                        });
                    }

                    super.onConfigurationChanged(newConfig);
                }
            };
        }

        if (scannerView.getParent() == null) {
            getCurrentActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    getMainViewGroup().addView(scannerView);
                    updatePreviewContainerValues();
                }
            });
        } else {
            updatePreviewContainerValues();
        }
    }

    private ViewGroup getMainViewGroup() {
        return getCurrentActivity().findViewById(android.R.id.content);
    }

    private Boolean isReaderInit(Promise Promise) {
        if (readerDevice != null) {
            return true;
        } else {
            if (Promise != null) {
                DEBUG_LOG("Rejected isReaderInit");
                Promise.reject("0", "Reader device not initialized");
            }
            return false;
        }
    }

    private void updatePreviewContainerValues() {
        Display display = ((WindowManager) getCurrentActivity().getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        final Point size = new Point();
        display.getSize(size);

        param_positionX = position_xp / 100 * size.x;
        param_positionY = position_yp / 100 * size.y;

        param_sizeWidth = position_wp / 100 * size.x;
        param_sizeHeight = position_hp / 100 * size.y;

        // ensure UI thread
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            updateScannerViewPosition();
        } else {
            getCurrentActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    updateScannerViewPosition();
                }
            });
        }
    }

    @ReactMethod
    private void setCameraMode(int cameraMode) {
        param_cameraMode = cameraMode;
    }

    @ReactMethod
    private void setPreviewOptions(int previewOptions) {
        param_previewOptions = previewOptions;
    }

    ////////////////////////////////////////////////////
    //SDK API methods
    @ReactMethod
    private void getAvailability(Promise promise) {
        if (isReaderInit(promise)) {
            ReaderDevice.Availability availability = (readerDevice != null) ? readerDevice.getAvailability() : null;
            promise.resolve(availability.ordinal());
        }
    }

    @ReactMethod
    private void enableImage(boolean arg, Promise promise) {
        if (isReaderInit(promise)) {
            readerDevice.enableImage(arg);
            promise.resolve(true);
        }
    }

    @ReactMethod
    private void enableImageGraphics(boolean arg, Promise promise) {
        if (isReaderInit(promise)) {
            readerDevice.enableImageGraphics(arg);
            promise.resolve(true);
        }
    }

    @ReactMethod
    private void setParser(int arg, Promise promise) {
        if (isReaderInit(promise)) {
            ResultParser[] parsers = ResultParser.values();

            if (arg >= 0 && arg <= parsers.length) {
                readerDevice.setParser(parsers[arg]);
                promise.resolve(true);
            } else {
                promise.reject("setParser invalid argument");
            }
        }
    }

    /**
     * @name connect
     * @desc Connect to the chosen Reader Device
     */
    @ReactMethod
    private void connect(final Promise Promise) {
        if (isReaderInit(Promise)) {
            readerDevice.connect(new ReaderDevice.OnConnectionCompletedListener() {
                @Override
                public void onConnectionCompleted(ReaderDevice readerDevice, Throwable throwable) {
                    if (throwable != null) {
                        Log.e("CMBScanner", "ReaderDevice failed to connect: " + throwable.getMessage());
                        DEBUG_LOG("Rejected connect");
                        Promise.reject("0", throwable.getMessage());
                    } else {
                        DEBUG_LOG("Resolved connect");
                        Promise.resolve(null);
                    }
                }
            });
        }
    }

    private String regKey = null;

    @ReactMethod
    private void registerSDK(String key) {
        regKey = key;
    }

    @ReactMethod
    private void disconnect(final Promise Promise) {
        if (isReaderInit(Promise)) {
            readerDevice.disconnect();
            DEBUG_LOG("Resolved disconnect");
            Promise.resolve(null);

            Activity activity = getCurrentActivity();
            if (activity != null) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        removeScannerView();
                    }
                });
            }
        }
    }

    @ReactMethod
    private void getConnectionState(Promise promise) {
        if (isReaderInit(promise)) {
            promise.resolve(readerDevice.getConnectionState().ordinal());
        }
    }

    @ReactMethod
    private void startScanning(Promise Promise) {
        if (readerDevice != null && readerDevice.getConnectionState().ordinal() == 2) {
//            setScannerViewHidden(false);
            toggleScanner(true);
            DEBUG_LOG("Resolved startScanning");
            Promise.resolve(null);
        } else {
            DEBUG_LOG("Rejected startScanning");
            Promise.reject("0", "Reader device not initialized");
        }
    }

    //stop scanning callback will always return false, which is the state of the "SCANNER"
    //on the javascript side of things we use the same callback function for both startScanning and stopScanning
    //and a true value would mean the scanner is active, a false value would mean it's not
    @ReactMethod
    private void stopScanning(Promise promise) {
        //added by lazyvlad to save the callback so when onReadResultReceived happens and we need to stop the scanner we can
        //have the proper callback
//        scanningStateChangedEventId = Promise;

        if (isReaderInit(promise)) {
            toggleScanner(false);
            if (promise != null) {
                DEBUG_LOG("Resolved stopScanning");
                promise.resolve(null);
            }
        }
    }

//    private void setScannerViewHidden(final boolean scannerViewHidden) {
//        if (scannerView != null)
//            getCurrentActivity().runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    scannerView.setVisibility(scannerViewHidden ? View.INVISIBLE : View.VISIBLE);
//                }
//            });
//    }

    private void toggleScanner(boolean scan) {
        if (scan) {
            startScan();
        } else {
            stopScan();
        }
        isScanning = scan;
    }

    private void startScan() {
        readerDevice.getDataManSystem().sendCommand("GET TRIGGER.TYPE", new DataManSystem.OnResponseReceivedListener() {
            @Override
            public void onResponseReceived(DataManSystem dataManSystem, DmccResponse dmccResponse) {
                if (dmccResponse.getError() == null)
                    param_triggerType = Integer.parseInt(dmccResponse.getPayLoad());
            }
        });

        readerDevice.startScanning();
        emitEvent(CMBEvent.scanningStateChangedEvent, true);
    }

    private void stopScan() {
        readerDevice.stopScanning();
    }

    @ReactMethod
    private void beep(Promise Promise) {
        if (isReaderInit(Promise)) {
            readerDevice.beep();
            DEBUG_LOG("Resolved beep");
            Promise.resolve(null);
        }
    }

    @ReactMethod
    private void getDeviceBatteryLevel(final Promise Promise) {
        if (isReaderInit(Promise)) {
            readerDevice.getDeviceBatteryLevel(new ReaderDevice.OnDeviceBatteryLevelListener() {
                @Override
                public void onDeviceBatteryLevelReceived(ReaderDevice readerDevice, int i, Throwable throwable) {
                    if (throwable != null) {
                        DEBUG_LOG("Rejected getDeviceBatteryLevel");
                        Promise.reject("0", throwable.getMessage());
                    } else {
                        DEBUG_LOG("Resolved getDeviceBatteryLevel");
                        Promise.resolve(i);
                    }
                }
            });
        }
    }

    @ReactMethod
    private void setSymbology(int symbology, boolean enable, final String cmdIdentifier) {
        if (isReaderInit(null)) {

            if (symbologies.length <= symbology) {
                Log.e("setSymbology", "Out of range " + symbology);
                return;
            }

            readerDevice.setSymbologyEnabled(
                    symbologies[symbology],
                    enable,
                    new ReaderDevice.OnSymbologyListener() {
                        @Override
                        public void onSymbologyEnabled(ReaderDevice readerDevice, ReaderDevice.Symbology symbology, Boolean aBoolean, Throwable throwable) {
                            WritableMap params = Arguments.createMap();
                            params.putString("commandID", cmdIdentifier);
                            params.putBoolean("success", throwable == null);
                            params.putString("message", (throwable != null) ? throwable.getMessage() : "");
                            params.putString("eventType", "setSymbology");

                            emitEvent(CMBEvent.cmbCommandCompletionEvent, params);
                        }
                    }
            );
        } else {
            WritableMap params = Arguments.createMap();
            params.putString("commandID", cmdIdentifier);
            params.putBoolean("success", false);
            params.putString("message", "Reader device not initialized");
            params.putString("eventType", "setSymbology");

            emitEvent(CMBEvent.cmbCommandCompletionEvent, params);
        }
    }

    @ReactMethod
    private void isSymbologyEnabled(int symbology, final String cmdIdentifier) {
        if (isReaderInit(null)) {
            readerDevice.isSymbologyEnabled(
                    ReaderDevice.Symbology.values()[symbology],
                    new ReaderDevice.OnSymbologyListener() {
                        @Override
                        public void onSymbologyEnabled(ReaderDevice readerDevice, ReaderDevice.Symbology symbology, Boolean aBoolean, Throwable throwable) {
                            WritableMap params = Arguments.createMap();
                            params.putString("commandID", cmdIdentifier);
                            params.putBoolean("success", throwable == null);
                            params.putString("message", (throwable != null) ? throwable.getMessage() : "");
                            params.putString("eventType", "isSymbologyEnabled");
                            params.putBoolean("response", aBoolean);

                            emitEvent(CMBEvent.cmbCommandCompletionEvent, params);
                        }
                    }
            );
        } else {
            WritableMap params = Arguments.createMap();
            params.putString("commandID", cmdIdentifier);
            params.putBoolean("success", false);
            params.putString("message", "Reader device not initialized");
            params.putString("eventType", "isSymbologyEnabled");

            emitEvent(CMBEvent.cmbCommandCompletionEvent, params);
        }
    }

    @ReactMethod
    private void setLightsOn(boolean on, final Promise promise) {
        if (isReaderInit(promise))
            readerDevice.setLightsOn(
                    on,
                    new ReaderDevice.OnLightsListener() {
                        @Override
                        public void onLightsOnCompleted(ReaderDevice readerDevice, Boolean aBoolean, Throwable throwable) {
                            if (throwable == null) {
                                promise.resolve(null);
                            } else {
                                promise.reject("0", throwable.getMessage());
                            }
                        }
                    }
            );
    }

    @ReactMethod
    private void isLightsOn(final Promise Promise) {
        if (isReaderInit(Promise))
            readerDevice.isLightsOn(
                    new ReaderDevice.OnLightsListener() {
                        @Override
                        public void onLightsOnCompleted(ReaderDevice readerDevice, Boolean aBoolean, Throwable throwable) {
                            if (throwable == null) {
                                DEBUG_LOG("Resolved isLightsOn");
                                Promise.resolve(aBoolean);
                            } else {
                                DEBUG_LOG("Rejected isLightsOn");
                                Promise.reject("0", throwable.getMessage());
                            }
                        }
                    }
            );
    }

    @ReactMethod
    private void resetConfig(final Promise Promise) {
        if (isReaderInit(Promise))
            readerDevice.resetConfig(
                    new ReaderDevice.OnResetConfigListener() {
                        @Override
                        public void onResetConfigCompleted(ReaderDevice readerDevice, Throwable throwable) {
                            if (throwable == null) {
                                DEBUG_LOG("Resolved resetConfig");
                                Promise.resolve(null);
                            } else {
                                DEBUG_LOG("Rejected resetConfig");
                                Promise.reject("0", throwable.getMessage());
                            }
                        }
                    }
            );
    }

    @ReactMethod
    private void sendCommand(final String commandString, final String cmdIdentifier) {
        if (isReaderInit(null)) {
            readerDevice.getDataManSystem().sendCommand(
                    commandString,
                    new DataManSystem.OnResponseReceivedListener() {
                        @Override
                        public void onResponseReceived(DataManSystem dataManSystem, DmccResponse dmccResponse) {
                            WritableMap response = Arguments.createMap();
                            response.putString("commandID", cmdIdentifier);
                            response.putString("eventType", "command");
                            response.putString("command", commandString);

                            if (dmccResponse.getError() == null) {
                                response.putBoolean("success", true);
                                response.putInt("status", 0);
                                response.putString("message", (dmccResponse.getPayLoad() != null) ? dmccResponse.getPayLoad() : "");
                            } else {
                                response.putBoolean("success", false);
                                response.putInt("status", 1);
                                response.putString("message", (dmccResponse.getPayLoad() != null) ? dmccResponse.getPayLoad() : "Command failed");
                            }

                            emitEvent(CMBEvent.cmbCommandCompletionEvent, response);
                        }
                    });
        } else {
            WritableMap response = Arguments.createMap();
            response.putString("commandID", cmdIdentifier);
            response.putString("eventType", "command");
            response.putString("command", commandString);
            response.putBoolean("success", false);
            response.putString("message", "Reader device not initialized");

            emitEvent(CMBEvent.cmbCommandCompletionEvent, response);
        }
    }

    @ReactMethod
    public void setPreviewContainerPositionAndSize(ReadableArray args) {
        if (args != null && args.size() == 4) {
            position_xp = (float) args.getDouble(0);
            position_yp = (float) args.getDouble(1);
            position_wp = (float) args.getDouble(2);
            position_hp = (float) args.getDouble(3);
        }

        param_isScannerFullScreen = false;

        updatePreviewContainerValues();

        try {
            readerDevice.setCameraPreviewContainer(scannerView);
        } catch (Exception ignored) {
        }
    }

    @ReactMethod
    public void setPreviewContainerFullScreen() {
        if (readerDevice != null && param_deviceType == 1) {
            readerDevice.setCameraPreviewContainer(null);
        }

        param_isScannerFullScreen = true;
    }

    @ReactMethod
    public void setStopScannerOnRotate(boolean arg) {
        cmb_stopScanningOnRotate = arg;
    }

    @Override
    public void onConnectionStateChanged(final ReaderDevice readerDevice) {
        emitEvent(CMBEvent.connectionStateDidChangeOfReaderEvent, (readerDevice.getConnectionState().ordinal()));

        if (param_deviceType == DeviceType.MX_1000.ordinal() && readerDevice.getConnectionState() == ConnectionState.Connected) {
            if (lifecycleEventListener == null) {
                lifecycleEventListener = new LifecycleEventListener() {
                    @Override
                    public void onHostResume() {
                    }

                    @Override
                    public void onHostPause() {
                        readerDevice.disconnect();
                    }

                    @Override
                    public void onHostDestroy() {
                    }
                };
                getReactApplicationContext().addLifecycleEventListener(lifecycleEventListener);
            }
        } else if (readerDevice.getConnectionState() == ConnectionState.Disconnected) {
            getReactApplicationContext().removeLifecycleEventListener(lifecycleEventListener);
            lifecycleEventListener = null;
        }
    }

    @Override
    public void onReadResultReceived(ReaderDevice readerDevice, ReadResults readResults) {
        WritableMap jsonResult = Arguments.createMap();
        WritableArray jsonReadResults = Arguments.createArray();
        WritableArray jsonSubResults = Arguments.createArray();

        jsonResult.putString("xml", readResults.getXml());

        if (readResults.getCount() > 0) {
            jsonReadResults.pushMap(ReadResultToJsonObj(readResults.getResultAt(0)));
        }

        if (readResults.getSubResults() != null) {
            for (ReadResult item : readResults.getSubResults()) {
                jsonReadResults.pushMap(ReadResultToJsonObj(item));
                jsonSubResults.pushMap(ReadResultToJsonObj(item));
            }
        }

        jsonResult.putArray("subReadResults", jsonSubResults);
        jsonResult.putArray("readResults", jsonReadResults);

        emitEvent(CMBEvent.didReceiveReadResultFromReaderEvent, jsonResult);
        if (param_triggerType != 5) {
            // not in continuous scanning, scanner will stop
            emitEvent(CMBEvent.scanningStateChangedEvent, false);
            isScanning = false;
        }
    }

    private WritableMap ReadResultToJsonObj(ReadResult result) {
        WritableMap jsonResult = Arguments.createMap();

        if (result.isGoodRead()) {
            if (result.getSymbology() != null) {
                jsonResult.putInt("symbology", result.getSymbology().ordinal());
                jsonResult.putString("symbologyString", result.getSymbology().getName());
            }
            jsonResult.putString("readString", result.getReadString());
        } else {
            jsonResult.putInt("symbology", -1);
            jsonResult.putString("symbologyString", "NO READ");
            jsonResult.putString("readString", "");
        }

        jsonResult.putBoolean("goodRead", result.isGoodRead());

        if (result.getXml() != null) {
            jsonResult.putString("xml", result.getXml());
        }
        if (result.getImageGraphics() != null) {

            //This should be handled in SDK
            String svgXML = result.getImageGraphics();
            svgXML = svgXML.replace(svgXML.substring(svgXML.indexOf("<title"), svgXML.indexOf("<g")), "");

            jsonResult.putString("imageGraphics", svgXML);
        }

        if (result.getImage() != null) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            result.getImage().compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            byte[] byteArray = byteArrayOutputStream.toByteArray();

            String encoded = Base64.encodeToString(byteArray, Base64.DEFAULT);

            jsonResult.putString("image", encoded);
        }

        if (result.getParsedText() != null) {
            jsonResult.putString("parsedText", result.getParsedText());
        }

        if (result.getParsedJSON() != null) {
            jsonResult.putString("parsedJSON", result.getParsedJSON());
        }

        return jsonResult;
    }

    @Override
    public void onAvailabilityChanged(ReaderDevice readerDevice) {
        emitEvent(CMBEvent.availabilityDidChangeOfReaderEvent, (readerDevice.getAvailability().ordinal()));
    }

    private void emitEvent(CMBEvent event, Object params) {
        reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).
                emit(getEventName(event), params);
    }

    enum CMBEvent {
        didReceiveReadResultFromReaderEvent,
        availabilityDidChangeOfReaderEvent,
        connectionStateDidChangeOfReaderEvent,
        scanningStateChangedEvent,
        cmbCommandCompletionEvent
    }

    private String getEventName(CMBEvent event) {
        switch (event) {
            case didReceiveReadResultFromReaderEvent:
                return "didReceiveReadResultFromReaderEvent";
            case availabilityDidChangeOfReaderEvent:
                return "availabilityDidChangeOfReaderEvent";
            case connectionStateDidChangeOfReaderEvent:
                return "connectionStateDidChangeOfReaderEvent";
            case scanningStateChangedEvent:
                return "scanningStateChangedEvent";
            case cmbCommandCompletionEvent:
                return "cmbCommandCompletionEvent";
            default:
                return "";
        }
    }

    @ReactMethod
    private void getSupportedEventNames(Callback callback) {
        String[] events = new String[5];
        events[0] = getEventName(CMBEvent.didReceiveReadResultFromReaderEvent);
        events[1] = getEventName(CMBEvent.availabilityDidChangeOfReaderEvent);
        events[2] = getEventName(CMBEvent.connectionStateDidChangeOfReaderEvent);
        events[3] = getEventName(CMBEvent.scanningStateChangedEvent);
        events[4] = getEventName(CMBEvent.cmbCommandCompletionEvent);

        callback.invoke((Object[]) events);
    }

    @ReactMethod
    private void imageFromSVG(String svg, final Promise promise) {
        Bitmap graphics = renderSvg(svg);

        if (graphics != null) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            graphics.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            byte[] byteArray = byteArrayOutputStream.toByteArray();

            String encoded = Base64.encodeToString(byteArray, Base64.DEFAULT);
            promise.resolve(encoded);
        } else {
            promise.reject("Failed to convert svg to image");
        }
    }

    private Bitmap renderSvg(String svgString) {
        try {
            int svgWidth = 0;
            int svgHeight = 0;

            String regex = "<svg.*width=\"(.*)px\".*height=\"(.*)px\".*>";
            Pattern mPattern = Pattern.compile(regex);
            Matcher matcher = mPattern.matcher(svgString.replaceAll("\\r", "   ").replaceAll("\\n", "   "));
            if (matcher.find() && matcher.group(1) != null && matcher.group(2) != null) {
                svgWidth = Integer.parseInt(matcher.group(1));
                svgHeight = Integer.parseInt(matcher.group(2));
            }

            if (param_deviceType == DeviceType.MOBILE_DEVICE.ordinal() && (svgWidth == 0 || svgHeight == 0)) {
                svgWidth = scannerView.getWidth();
                svgHeight = scannerView.getHeight();
            }

            SVG svg = SVG.getFromString(svgString);
            svg.setDocumentHeight(svgHeight);
            svg.setDocumentWidth(svgWidth);

            Bitmap svgBitmap = Bitmap.createBitmap(svgWidth, svgHeight, Bitmap.Config.ARGB_4444);
            Canvas canvas = new Canvas(svgBitmap);
            svg.renderToCanvas(canvas);

            return svgBitmap;
        } catch (Exception ignored) {
        }

        return null;
    }

    @ReactMethod
    private void toggleConnectionAlert(boolean arg) {
        if (arg) {
            if (connectingAlert == null) {
                final Activity activity = getCurrentActivity();
                if (activity != null) {
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            AlertDialog.Builder connectingAlertBuilder = new AlertDialog.Builder(activity);
                            connectingAlertBuilder
                                    .setTitle("Connecting")
                                    .setMessage("Please wait...")
                                    .setCancelable(false);
                            connectingAlert = connectingAlertBuilder.create();
                            connectingAlert.show();
                        }
                    });
                }

            }
        } else {
            if (connectingAlert != null) {
                final Activity activity = getCurrentActivity();
                if (activity != null) {
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            connectingAlert.dismiss();
                            connectingAlert = null;
                        }
                    });
                }
            }
        }
    }

    private void DEBUG_LOG(String log) {
        if (DEBUG_LOGS)
            Log.d("RnCmbSdkModule", log);
    }
}

abstract class ScannerViewContainer extends RelativeLayout {

    public ScannerViewContainer(Context context) {
        super(context);
        configureScannerView();
    }

    public ScannerViewContainer(Context context, AttributeSet attrs) {
        super(context, attrs);
        configureScannerView();
    }

    public ScannerViewContainer(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        configureScannerView();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public ScannerViewContainer(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        configureScannerView();
    }

    void configureScannerView() {
        this.setFocusableInTouchMode(false);
        this.setFocusable(false);
    }
}